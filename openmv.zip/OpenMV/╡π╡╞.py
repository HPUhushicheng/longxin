import time
from pyb import LED
LED(3).on()
time.sleep_ms(500)     #延时500ms
